package servlets;

import Cinema.GestionP;
import Cinema.Pelicula;
import java.io.File;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@WebServlet(name = "SvPeliculas", urlPatterns = {"/SvPeliculas"})
@MultipartConfig(fileSizeThreshold = 1024 * 1024, maxFileSize = 1024 * 1024 * 5, maxRequestSize = 1024 * 1024 * 10)
public class SvPeliculas extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private GestionP gestorP = new GestionP();
    private String uploadPath;

    @Override
    public void init() throws ServletException {
        super.init();
        uploadPath = getServletContext().getRealPath("") + File.separator + "portadas";
        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) uploadDir.mkdir();
    }

@Override
protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

    String action = request.getParameter("action");
    String idPelicula = request.getParameter("idPelicula");

    if (action != null) {
        switch (action) {
            case "delete":
                if (idPelicula != null) {
                    int id = Integer.parseInt(idPelicula);
                    gestorP.eliminarPelicula(id);
                }
                break;
            case "edit":
                if (idPelicula != null) {
                    int id = Integer.parseInt(idPelicula);
                    Pelicula pelicula = gestorP.buscarPelicula(id);
                    request.setAttribute("pelicula", pelicula);
                }
                break;
        }
    }

    // Cargar la lista de películas, incluso si está vacía
    List<Pelicula> peliculas = gestorP.listarPeliculas();
    request.setAttribute("peliculas", peliculas);
    request.getRequestDispatcher("registroPeliculas.jsp").forward(request, response);
}


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Obtener parámetros del formulario
        int idPelicula = Integer.parseInt(request.getParameter("idPelicula"));
        String titulo = request.getParameter("titulo");
        String sinopsis = request.getParameter("sinopsis");
        String director = request.getParameter("director");
        String fechaEstreno = request.getParameter("fechaEstreno");
        double calificacionCritica = Double.parseDouble(request.getParameter("calificacionCritica"));
        double calificacionAudiencia = Double.parseDouble(request.getParameter("calificacionAudiencia"));
        String cineSeleccionado = request.getParameter("cineSeleccionado");
        String portada = "portadas/default.png"; // Portada por defecto

        // Manejar la carga de la portada
        Part imagenPart = request.getPart("portada");
        if (imagenPart != null && imagenPart.getSize() > 0) {
            String fileName = getFileName(imagenPart);
            imagenPart.write(uploadPath + File.separator + fileName);
            portada = "portadas/" + fileName;
        }

        // Crear objeto Pelicula
        Pelicula pelicula = new Pelicula(idPelicula, titulo, sinopsis, director, fechaEstreno, calificacionCritica, calificacionAudiencia, portada, cineSeleccionado);
        String editar = request.getParameter("editar");

        // Ejecutar agregar o editar
        if ("true".equals(editar)) {
            gestorP.editarPelicula(pelicula);
        } else {
            gestorP.agregarPelicula(pelicula);
        }

        // Redirigir a la lista de películas
        response.sendRedirect("SvPeliculas");
    }

    private String getFileName(Part part) {
        String contentDisposition = part.getHeader("content-disposition");
        for (String cd : contentDisposition.split(";")) {
            if (cd.trim().startsWith("filename")) {
                return cd.substring(cd.indexOf('=') + 1).trim().replace("\"", "");
            }
        }
        return null;
    }
}
