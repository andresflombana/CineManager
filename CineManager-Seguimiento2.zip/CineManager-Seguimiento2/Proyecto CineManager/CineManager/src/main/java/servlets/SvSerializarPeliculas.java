package servlets;

import Cinema.CineManager;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;

@WebServlet("/SvSerializarPeliculas")
public class SvSerializarPeliculas extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        CineManager cineManager = new CineManager();

        try {
            cineManager.serializarPeliculas();  // Llama al método de serialización
            // Notifica al usuario del éxito
            response.getWriter().write("<script>alert('Serialización correcta'); window.location='index.jsp';</script>");
        } catch (Exception e) {
            // Notifica al usuario en caso de error
            response.getWriter().write("<script>alert('Error al serializar: " + e.getMessage() + "'); window.location='index.jsp';</script>");
        }
    }
}
