package Cinema;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import javax.swing.JOptionPane;

public class CineManager {
    // Enlistamos algunas peliculas en una contenedora estática como ejemplo para serializar.
    private Pelicula[] peliculas1;

    public CineManager() {
        peliculas1 = new Pelicula[0];
    }

    // Método para serializar la lista de películas usando una ruta relativa
    public void serializarPeliculas() throws IOException {
        // Ruta relativa que apunta a la carpeta "data" en el directorio raíz
        String rutaRelativa = "./data/peliculas.data";
        File archivo = new File(rutaRelativa);

        // Crear la carpeta "data" si no existe
        File carpeta = new File(archivo.getParent());
        if (!carpeta.exists()) {
            carpeta.mkdirs();
        }

        // Serializar el objeto de películas
        FileOutputStream fos = new FileOutputStream(archivo);
        ObjectOutputStream oos = new ObjectOutputStream(fos);
        oos.writeObject(peliculas1);
        oos.close();

        // En la impresión de consola puede ver la ruta donde se creó la serializacion.
        System.out.println("Archivo creado en: " + archivo.getAbsolutePath());
    }

    // Método que llama a la serialización con manejo de errores
    public void Método1() {
        try {
            serializarPeliculas();
            JOptionPane.showMessageDialog(null, "Serialización correcta", "Respuesta", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al serializar: " + e.getMessage(), "Respuesta", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        CineManager cineManager = new CineManager();
        cineManager.Método1();
    }
}
