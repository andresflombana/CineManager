package Cinema;

import java.util.ArrayList;
import java.util.List;

public class GestionP {

    private class NodoDoble {
        private Pelicula pelicula;
        private NodoDoble siguiente;
        private NodoDoble anterior;

        public NodoDoble(Pelicula pelicula) {
            this.pelicula = pelicula;
            this.siguiente = null;
            this.anterior = null;
        }

        public Pelicula getPelicula() {
            return pelicula;
        }

        public NodoDoble getSiguiente() {
            return siguiente;
        }

        public void setSiguiente(NodoDoble siguiente) {
            this.siguiente = siguiente;
        }
    }

    private NodoDoble cabeza;
    private NodoDoble cola;

    public GestionP() {
        this.cabeza = null;
        this.cola = null;
    }

    public void agregarPelicula(Pelicula pelicula) {
        NodoDoble nuevoNodo = new NodoDoble(pelicula);
        if (cabeza == null) {
            cabeza = nuevoNodo;
            cola = nuevoNodo;
        } else {
            cola.setSiguiente(nuevoNodo);
            nuevoNodo.anterior = cola;
            cola = nuevoNodo;
        }
    }

    public boolean eliminarPelicula(int idPelicula) {
        NodoDoble actual = cabeza;

        while (actual != null) {
            if (actual.getPelicula().getIdPelicula() == idPelicula) {
                if (actual.anterior != null) {
                    actual.anterior.setSiguiente(actual.getSiguiente());
                } else {
                    cabeza = actual.getSiguiente();
                }
                if (actual.getSiguiente() != null) {
                    actual.getSiguiente().anterior = actual.anterior;
                } else {
                    cola = actual.anterior;
                }
                return true;
            }
            actual = actual.getSiguiente();
        }
        return false;
    }

    public boolean editarPelicula(Pelicula peliculaModificada) {
        NodoDoble actual = cabeza;

        while (actual != null) {
            if (actual.getPelicula().getIdPelicula() == peliculaModificada.getIdPelicula()) {
                actual.getPelicula().setTitulo(peliculaModificada.getTitulo());
                actual.getPelicula().setSinopsis(peliculaModificada.getSinopsis());
                actual.getPelicula().setDirector(peliculaModificada.getDirector());
                actual.getPelicula().setFechaEstreno(peliculaModificada.getFechaEstreno());
                actual.getPelicula().setCalificacionCritica(peliculaModificada.getCalificacionCritica());
                actual.getPelicula().setCalificacionAudiencia(peliculaModificada.getCalificacionAudiencia());
                actual.getPelicula().setPortada(peliculaModificada.getPortada());
                actual.getPelicula().setCineSeleccionado(peliculaModificada.getCineSeleccionado());
                return true;
            }
            actual = actual.getSiguiente();
        }
        return false;
    }

    public Pelicula buscarPelicula(int idPelicula) {
        NodoDoble actual = cabeza;

        while (actual != null) {
            if (actual.getPelicula().getIdPelicula() == idPelicula) {
                return actual.getPelicula();
            }
            actual = actual.getSiguiente();
        }
        return null;
    }

    public List<Pelicula> listarPeliculas() {
        List<Pelicula> peliculas = new ArrayList<>();
        NodoDoble actual = cabeza;

        while (actual != null) {
            peliculas.add(actual.getPelicula());
            actual = actual.getSiguiente();
        }

        System.out.println("Películas encontradas: " + peliculas.size());
        return peliculas;
    }


    public boolean estaVacia() {
        return cabeza == null;
    }
}
