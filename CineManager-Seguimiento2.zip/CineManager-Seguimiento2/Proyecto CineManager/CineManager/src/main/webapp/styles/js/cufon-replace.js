Cufon.replace('#header .row-1 .fleft', { fontFamily: 'Gill Sans', color: '-linear-gradient(#bfbfbf, #919191)' });
Cufon.replace('#header .row-1 .fleft span', { fontFamily: 'Gill Sans', color: '-linear-gradient(#d72a18, #b60803)' });
Cufon.replace('#header .row-2 ul li, h2, h3, h4', { fontFamily: 'Gill Sans', hover:true });